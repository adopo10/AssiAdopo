public class VehiculeException extends RuntimeException {
    public VehiculeException() {

        super("le vehicule est déjà loué");
    }
}
