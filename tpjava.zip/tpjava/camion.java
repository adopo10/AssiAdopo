public  class camion extends vehicule implements louable {

        public int  capacitedechargement;
        public  int nombredessieux;
        camion (String immaticulation, String marque, String modele, int anneedemiseeservice, int kilometre,int capacitedechargement,int nombredessieux){
            super(immaticulation,marque,modele,anneedemiseeservice, kilometre);
            this.capacitedechargement=capacitedechargement;
            this.nombredessieux=nombredessieux;
        }

    @Override
    public void louer() throws VehiculeException {
        if (this.statut)throw new VehiculeException();
        this.statut=true;
    }
    @Override
    public void retourner() {
        if (!this.statut) throw new VehiculeException();
        this.statut=false;

    }

    @Override
        void calculerPrixLocation() {
            System.out.println("le prix  du camion est 5000$ ");
        }

    void aff() {
        super.aff();
        System.out.println("camion{" +
                "capacitedechargement=" + capacitedechargement +
                ", nombredessieux=" + nombredessieux +
                '}');
    }
}
