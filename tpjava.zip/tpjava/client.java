import java.util.ArrayList;
import java.util.List;
public class client {
     public  String nom;
     public  String prenom;
     public  int numeropermisconduire;
     public int numeroTel;
     public List<vehicule>locationsencours;

     public client(String nom, String prenom, int numeropermisconduire, int numeroTel) {
          this.nom = nom;
          this.prenom = prenom;
          this.numeropermisconduire = numeropermisconduire;
          this.numeroTel = numeroTel;
          locationsencours=new ArrayList<>();
     }
      void ajoutervoiture(vehicule vehicules){
          locationsencours.add(vehicules);
      }
     void supprimervehicul(vehicule vehicules){
          locationsencours.remove(vehicules);
     }


}
