public interface louable {
     void louer() throws VehiculeException;
     void retourner();
}
