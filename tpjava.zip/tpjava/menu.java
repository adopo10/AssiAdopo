
import java.util.Scanner;

public class menu {

    public static void main(String[] args) {
        parcAutomobile newparc=new parcAutomobile();
        Scanner Z = new Scanner(System.in);

        while (true) {
            System.out.println("\n console menu");

            System.out.println("\n1-ajouter un nouveau véhicule au parc ");

            System.out.println("\n2-ajouter un nouveau client ");

            System.out.println("\n3-louer un véhicule à un client ");

            System.out.println("\n4-retourner un véhicule ");

            System.out.println("\n5-lister les véhicules disponibles ou loués ");

            System.out.println("\n choisissez une option!! ");


            int choix = Z.nextInt();

            switch (choix) {

                case 1:
                    newparc.ajoutervehicule();
                    break;
                case 2:
                    newparc.ajouterunclient();
                    break;
                case 3:
                    newparc.louervehicule();
                    break;
                case 4:
                    newparc.retournervehicule();
                    break;
                case 5 :
                   newparc.listervehicule();

            }
        }
    }
}
