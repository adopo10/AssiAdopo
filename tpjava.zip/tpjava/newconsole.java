import java.util.ArrayList;
import java.util.Scanner;
public class newconsole {
    // --- Classe abstraite Vehicule ---
    abstract class Vehicule {
        protected String immatriculation;
        protected String marque;
        protected String modele;
        protected int anneeService;
        protected double kilometrage;
        protected boolean statut;  // true = Loué, false = Disponible

        public Vehicule(String immatriculation, String marque, String modele, int anneeService, double kilometrage) {
            this.immatriculation = immatriculation;
            this.marque = marque;
            this.modele = modele;
            this.anneeService = anneeService;
            this.kilometrage = kilometrage;
            this.statut = false; // Par défaut, disponible
        }

        public boolean estDisponible() {
            return !statut;
        }

        public void louer() throws VehiculeIndisponibleException {
            if (statut) {
                throw new VehiculeIndisponibleException("Le véhicule est déjà loué.");
            }
            statut = true;
        }

        public void retourner() {
            statut = false;
        }

        @Override
        public String toString() {
            String etat = statut ? "Loué" : "Disponible";
            return String.format("%s %s (%s) - %s", marque, modele, immatriculation, etat);
        }

        public abstract double calculerPrixLocation();
    }

    // --- Sous-classe Voiture ---
    class Voiture extends Vehicule {
        private int nombrePlaces;
        private String carburant;

        public Voiture(String immatriculation, String marque, String modele, int anneeService, double kilometrage,
                       int nombrePlaces, String carburant) {
            super(immatriculation, marque, modele, anneeService, kilometrage);
            this.nombrePlaces = nombrePlaces;
            this.carburant = carburant;
        }

        @Override
        public double calculerPrixLocation() {
            return 50.0 + (kilometrage * 0.2);
        }
    }

    // --- Sous-classe Camion ---
    class Camion extends Vehicule {
        private double capaciteChargement;
        private int nombreEssieux;

        public Camion(String immatriculation, String marque, String modele, int anneeService, double kilometrage,
                      double capaciteChargement, int nombreEssieux) {
            super(immatriculation, marque, modele, anneeService, kilometrage);
            this.capaciteChargement = capaciteChargement;
            this.nombreEssieux = nombreEssieux;
        }

        @Override
        public double calculerPrixLocation() {
            return 100.0 + (capaciteChargement * 10);
        }
    }

    // --- Classe Client ---
    class Client {
        private String nom;
        private String prenom;
        private String numeroPermis;
        private String numeroTelephone;
        private ArrayList<Vehicule> locations;

        public Client(String nom, String prenom, String numeroPermis, String numeroTelephone) {
            this.nom = nom;
            this.prenom = prenom;
            this.numeroPermis = numeroPermis;
            this.numeroTelephone = numeroTelephone;
            this.locations = new ArrayList<>();
        }

        public String getNumeroPermis() {
            return numeroPermis;
        }

        public void ajouterLocation(Vehicule vehicule) {
            locations.add(vehicule);
        }

        public void retournerVehicule(Vehicule vehicule) {
            locations.remove(vehicule);
        }

        @Override
        public String toString() {
            return nom + " " + prenom + " - Permis: " + numeroPermis;
        }
    }

    // --- Exception Personnalisée ---
    class VehiculeIndisponibleException extends Exception {
        public VehiculeIndisponibleException(String message) {
            super(message);
        }
    }

    // --- Classe ParcAutomobile ---
    class ParcAutomobile {
        private ArrayList<Vehicule> vehicules;
        private ArrayList<Client> clients;

        public ParcAutomobile() {
            this.vehicules = new ArrayList<>();
            this.clients = new ArrayList<>();
        }

        public void ajouterVehicule(Vehicule vehicule) {
            vehicules.add(vehicule);
        }

        public void ajouterClient(Client client) {
            clients.add(client);
        }

        public ArrayList<Vehicule> listerVehiculesDisponibles() {
            ArrayList<Vehicule> disponibles = new ArrayList<>();
            for (Vehicule v : vehicules) {
                if (v.estDisponible()) {
                    disponibles.add(v);
                }
            }
            return disponibles;
        }

        public ArrayList<Vehicule> listerVehiculesLoues() {
            ArrayList<Vehicule> loues = new ArrayList<>();
            for (Vehicule v : vehicules) {
                if (!v.estDisponible()) {
                    loues.add(v);
                }
            }
            return loues;
        }

        public Vehicule rechercherVehicule(String immatriculation) {
            for (Vehicule v : vehicules) {
                if (v.immatriculation.equals(immatriculation)) {
                    return v;
                }
            }
            return null;
        }

        public Client rechercherClient(String numeroPermis) {
            for (Client client : clients) {
                if (client.getNumeroPermis().equals(numeroPermis)) {
                    return client;
                }
            }
            return null;
        }
    }

    // --- Classe principale Application ---
    public class Application {
        public void main(String[] args) {
            Scanner scanner = new Scanner(System.in);
            ParcAutomobile parc = new ParcAutomobile();

            while (true) {
                System.out.println("\n--- Menu ---");
                System.out.println("1. Ajouter un véhicule");
                System.out.println("2. Ajouter un client");
                System.out.println("3. Lister véhicules disponibles");
                System.out.println("4. Lister véhicules loués");
                System.out.println("5. Louer un véhicule");
                System.out.println("6. Retourner un véhicule");
                System.out.println("7. Quitter");
                System.out.print("Choix: ");
                int choix = scanner.nextInt();
                scanner.nextLine();

                switch (choix) {
                    case 1 -> ajouterVehicule(scanner, parc);
                    case 2 -> ajouterClient(scanner, parc);
                    case 3 -> listerVehicules(parc.listerVehiculesDisponibles(), "disponibles");
                    case 4 -> listerVehicules(parc.listerVehiculesLoues(), "loués");
                    case 5 -> louerVehicule(scanner, parc);
                    case 6 -> retournerVehicule(scanner, parc);
                    case 7 -> {
                        System.out.println("Au revoir !");
                        scanner.close();
                        return;
                    }
                    default -> System.out.println("Choix invalide.");
                }
            }
        }

        // Méthodes supplémentaires
        private void ajouterVehicule(Scanner scanner, ParcAutomobile parc) {
            System.out.print("Type (1. Voiture, 2. Camion): ");
            int type = scanner.nextInt();
            scanner.nextLine();

            System.out.print("Immatriculation: ");
            String immatriculation = scanner.nextLine();
            System.out.print("Marque: ");
            String marque = scanner.nextLine();
            System.out.print("Modèle: ");
            String modele = scanner.nextLine();
            System.out.print("Année de mise en service: ");
            int anneeService = scanner.nextInt();
            System.out.print("Kilométrage: ");
            double kilometrage = scanner.nextDouble();

            if (type == 1) {
                System.out.print("Nombre de places: ");
                int places = scanner.nextInt();
                scanner.nextLine();
                System.out.print("Carburant: ");
                String carburant = scanner.nextLine();
                parc.ajouterVehicule(new Voiture(immatriculation, marque, modele, anneeService, kilometrage, places, carburant));
            } else {
                System.out.print("Capacité de chargement (tonnes): ");
                double capacite = scanner.nextDouble();
                System.out.print("Nombre d'essieux: ");
                int essieux = scanner.nextInt();
                parc.ajouterVehicule(new Camion(immatriculation, marque, modele, anneeService, kilometrage, capacite, essieux));
            }

            System.out.println("Véhicule ajouté avec succès !");
        }

        private void ajouterClient(Scanner scanner, ParcAutomobile parc) {
            System.out.print("Nom: ");
            String nom = scanner.nextLine();
            System.out.print("Prénom: ");
            String prenom = scanner.nextLine();
            System.out.print("Numéro de permis: ");
            String permis = scanner.nextLine();
            System.out.print("Téléphone: ");
            String telephone = scanner.nextLine();
            parc.ajouterClient(new Client(nom, prenom, permis, telephone));
            System.out.println("Client ajouté avec succès !");
        }

        private static void listerVehicules(ArrayList<Vehicule> vehicules, String statut) {
            System.out.println("\nVéhicules " + statut + " :");
            for (Vehicule v : vehicules) {
                System.out.println(v);
            }
        }

        private static void louerVehicule(Scanner scanner, ParcAutomobile parc) {
            System.out.print("Immatriculation du véhicule à louer: ");
            String immatriculation = scanner.nextLine();
            Vehicule vehicule = parc.rechercherVehicule(immatriculation);
            if (vehicule == null || !vehicule.estDisponible()) {
                System.out.println("Véhicule non disponible.");
                return;
            }

            System.out.print("Numéro de permis du client: ");
            String permis = scanner.nextLine();
            Client client = parc.rechercherClient(permis);
            if (client == null) {
                System.out.println("Client non trouvé.");
                return;
            }

            try {
                vehicule.louer();
                client.ajouterLocation(vehicule);
                System.out.println("Véhicule loué avec succès !");
            } catch (VehiculeIndisponibleException e) {
                System.out.println(e.getMessage());
            }
        }

        private static void retournerVehicule(Scanner scanner, ParcAutomobile parc) {
            System.out.print("Immatriculation du véhicule à retourner: ");
            String immatriculation = scanner.nextLine();
            Vehicule vehicule = parc.rechercherVehicule(immatriculation);
            if (vehicule == null || vehicule.estDisponible()) {
                System.out.println("Véhicule non trouvé ou déjà disponible.");
                return;
            }

            System.out.print("Numéro de permis du client: ");
            String permis = scanner.nextLine();
            Client client = parc.rechercherClient(permis);
            if (client == null) {
                System.out.println("Client non trouvé.");
                return;
            }

            vehicule.retourner();
            client.retournerVehicule(vehicule);
            System.out.println("Véhicule retourné avec succès !");
        }
    }
}
