import java.util.ArrayList;
import java.util.Scanner;

public class parcAutomobile {
    public ArrayList<vehicule> mesvehicules;
    public ArrayList<client> mesclients;

    parcAutomobile(){

        mesvehicules = new ArrayList<>();
        mesclients = new ArrayList<>();
    }
    void ajouterVehicule(vehicule vehicule){

        mesvehicules.add(vehicule);
    }

    void affichervehicules() {

        for (vehicule i : mesvehicules) {
            System.out.println("les vehicules sont " + i);
        }
    }

    void retirervehicule(vehicule vehicule) {
        mesvehicules.remove(vehicule);
    }

        void ajouterclient(client client) {

        mesclients.add(client);
    }

    void afficherclient() {

        for (client c : mesclients) {
            System.out.println("les vehicules sont " +c);
        }
    }

    void retirerclient(client client) {
        mesclients.remove(client);

    }
    void ajoutervehicule(){
        Scanner Z = new Scanner(System.in);
        System.out.println(" vous avez  choisis d'ajouter un nouveau vehicule \n vous choisissez quel type de vehicule ? \n1 voitures ? \n 2 camion");
        int choix2 = Z.nextInt();
        if (choix2 == 1) {
            System.out.println("vous avez choisis une voiture");
            String m = Z.nextLine();
            System.out.println("entrez une marque");
            String marque = Z.nextLine();
            System.out.println("entrez un modele");
            String modele = Z.nextLine();
            System.out.println("entrez une immatriculation");
            String immaticulation = Z.nextLine();
            System.out.println("entrez une annee de mise en service");
            int anneedemiseeservice = Z.nextInt();
            System.out.println("entrez un nombre de places");
            int nombredeplaces = Z.nextInt();
            System.out.println("entrez un caburant");
            String caburant = Z.nextLine();
            System.out.println("entrez un kilometrage");
            int kilometrage = Z.nextInt();
            voiture newvoiture = new voiture(immaticulation, marque, modele, anneedemiseeservice, kilometrage, nombredeplaces, caburant);
            System.out.println("votre voiture est " + newvoiture);
            mesvehicules.add(newvoiture);
        }
        if (choix2 == 2) {
            System.out.println("vous avez choisis un camoin");
            String m = Z.nextLine();
            System.out.println("entrez une immatriculation");
            String immaticulation = Z.nextLine();
            System.out.println("entrez une marque");
            String marque = Z.nextLine();
            System.out.println("entrez un modele");
            String modele = Z.nextLine();
            System.out.println("entrez une annee de mise en service");
            int anneedemiseeservice = Z.nextInt();
            System.out.println("entrez une capacite de chargement");
            int capacitedechargement = Z.nextInt();
            System.out.println("entrez un nombre d'essieux");
            int nombredessieux = Z.nextInt();
            System.out.println("entrez un kilometrage");
            int kilometrage= Z.nextInt();
            camion newcamion = new camion(immaticulation, marque, modele, anneedemiseeservice,kilometrage, capacitedechargement,nombredessieux);
            mesvehicules.add(newcamion);
        }
    }
   void ajouterunclient(){
       Scanner Z = new Scanner(System.in);
       System.out.println("vous avez choisi d'ajouter un client");
       System.out.println("ajouter un nom");
       String nom=Z.nextLine();
       System.out.println("entrez un prenom");
       String prenom = Z.nextLine();
       System.out.println("entrez un numero permis de conduire");
       int numeropermisconduire = Z.nextInt();
       System.out.println("entrez une numero de Telephone ");
       int numeroTel = Z.nextInt();
       client newclient=new client( nom,prenom,numeropermisconduire,numeroTel);
       mesclients.add(newclient);
   }
   void louervehicule(){
       Scanner Z = new Scanner(System.in);
       System.out.println("Entrer le nom du client : ");
       String no = Z.nextLine();
       System.out.println("\nEntrez l'immatriculation de la voiture : ");
       String imma = Z.nextLine();
       for (client j : mesclients){
           for (vehicule t : mesvehicules){
               if(no.equals(j.nom)){
                    if (imma.equals(t.immaticulation)){
                       j.ajoutervoiture(t);
                       t.louer();
                   } else System.out.println("Aucun véhicule du parc n'a ce matricule");
               }else System.out.println("Aucun client du parc n'a ce nom");
           }
       }
   }
    void retournervehicule(){
        Scanner Z = new Scanner(System.in);
        System.out.println("Entrer le nom du client : ");
        String no = Z.nextLine();
        System.out.println("\nEntrez l'immatriculation de la voiture : ");
        String imma = Z.nextLine();
        for (client j : mesclients){
            for (vehicule t : mesvehicules){
                if(no.equals(j.nom)){
                    if (imma == t.immaticulation){

                        j.supprimervehicul(t);
                        t.retourner();
                    }
                }
            }
        }
    }
    void listervehicule(){
        for ( vehicule m : mesvehicules){
            m.aff();
        }
    }


}