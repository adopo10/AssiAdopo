abstract class vehicule {

        public String immaticulation;
        public  String marque;
        public  String modele;
        public int anneedemiseenservice;
        public int kilometre;
        public boolean statut;

        vehicule(String immaticulation, String marque, String modele, int anneedemiseeservice, int kilometre){

            this.immaticulation=immaticulation;
            this.marque=marque;
            this.modele=modele;
            this.anneedemiseenservice=anneedemiseeservice;
            this.kilometre=kilometre;
            this.statut= false;

        }

        void aff() {
            System.out.println( "vehicule{" +
                    "immaticulation=" + immaticulation +
                    ", marque='" + marque + '\'' +
                    ", modele='" + modele + '\'' +
                    ", anneedemiseenservice=" + anneedemiseenservice +
                    ", kilometre=" + kilometre +
                    ", statut=" + ((statut) ? "Loué" : "Disponible") +
                    '}');
        }
        void louer(){
            this.statut =true;
        }
        void retourner(){
            this.statut =false;
        }

        abstract void calculerPrixLocation();
    }



