public class voiture extends vehicule implements louable {

    public int nombredeplaces;
    public String caburant;

    @Override
    public void louer() throws VehiculeException {
        if (this.statut) throw new VehiculeException();
        this.statut = true;
    }

    @Override
    public void retourner() {
        if (!this.statut) throw new VehiculeException();
        this.statut = false;
    }
    voiture(String immaticulation, String marque, String modele, int anneedemiseeservice, int kilometre,int nombredeplaces,String caburant){
        super(immaticulation,marque,modele,anneedemiseeservice, kilometre);
        this.nombredeplaces=nombredeplaces;
        this.caburant=caburant;
    }
    @Override
    void calculerPrixLocation() {
        return;
    }

    void aff() {
        super.aff();
        System.out.println("voiture{" +
                "nombredeplaces=" + nombredeplaces +
                ", caburant='" + caburant + '\'' +
                '}');


    }

}


